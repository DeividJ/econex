/* AgroAlerta · Análisis de suelo y aptitud agrícola (módulo independiente).
   No modifica ni depende de las otras funciones: crea su propia sección y lee /data/noa-aptitud.json */
(() => {
  const DATA_URLS = { noa: '/data/noa-aptitud.json', nea: '/data/nea-aptitud.json', cuyo: '/data/cuyo-aptitud.json', pampeana: '/data/pampeana-aptitud.json', patagonia: '/data/patagonia-aptitud.json' };
  const MONTHS = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
  const MONTH_NAMES = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
  const LEVELS = {
    alta:  { cls:'alta',  label:'Aptitud alta' },
    media: { cls:'media', label:'Aptitud media (con limitantes)' },
    baja:  { cls:'baja',  label:'Aptitud baja · No apto para plantar' },
    no:    { cls:'no',    label:'No recomendado · No apto' }
  };
  let db = null;          // base de la región activa
  const dbs = {};         // bases de todas las regiones, por id

  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const norm = s => String(s ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  const seasonOf = m => (m === 12 || m <= 2) ? 'verano' : m <= 5 ? 'otoño' : m <= 8 ? 'invierno' : 'primavera';

  function lev(a, b) {
    const dp = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
    for (let j = 1; j <= b.length; j++) dp[0][j] = j;
    for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++)
      dp[i][j] = Math.min(dp[i-1][j] + 1, dp[i][j-1] + 1, dp[i-1][j-1] + (a[i-1] === b[j-1] ? 0 : 1));
    return dp[a.length][b.length];
  }
  function findCrop(text) {
    const q = norm(text);
    if (!q) return null;
    let best = null;
    for (const c of db.cultivos) {
      const names = [c.nombre, ...c.aliases].map(norm);
      if (names.includes(q)) return c;
      if (names.some(n => n.length >= 4 && (q.includes(n) || n.includes(q)) && q.length >= 4)) best = best || c;
    }
    if (best) return best;
    let min = 99, hit = null;
    for (const c of db.cultivos) for (const n of [c.nombre, ...c.aliases].map(norm)) {
      const d = lev(q, n);
      if (d < min && d <= Math.max(1, Math.floor(n.length / 4))) { min = d; hit = c; }
    }
    return hit;
  }

  function windowFor(crop, subId) {
    const o = crop.siembraZona?.[subId];
    return o ? { meses: o.meses, texto: o.texto } : crop.siembra;
  }
  function monthStrip(months) {
    const now = new Date().getMonth() + 1;
    return `<div class="suelo-months" role="img" aria-label="Meses favorables: ${esc(months.map(m => MONTH_NAMES[m-1]).join(', '))}">${MONTHS.map((n, i) => {
      const m = i + 1;
      return `<span class="suelo-month${months.includes(m) ? ' on' : ''}${m === now ? ' now' : ''}" title="${esc(MONTH_NAMES[i])}${months.includes(m) ? ' · época favorable' : ''}${m === now ? ' · mes actual' : ''}">${n}</span>`;
    }).join('')}</div><div class="suelo-months-legend"><span><i class="suelo-month on"></i>Época favorable</span><span><i class="suelo-month now"></i>Mes actual</span></div>`;
  }
  function timingMessage(months) {
    const now = new Date().getMonth() + 1;
    if (months.includes(now)) return `Estamos en <b>época favorable</b> (${MONTH_NAMES[now-1]}).`;
    for (let k = 1; k <= 12; k++) {
      const m = ((now - 1 + k) % 12) + 1;
      if (months.includes(m)) return `Hoy (${MONTH_NAMES[now-1]}) <b>no es época favorable</b>. La próxima comienza en <b>${MONTH_NAMES[m-1]}</b> (en ${k} ${k === 1 ? 'mes' : 'meses'}).`;
    }
    return '';
  }
  function seasonsText(months) {
    const order = ['primavera','verano','otoño','invierno'];
    const set = new Set(months.map(seasonOf));
    return order.filter(s => set.has(s)).join(' y ');
  }
  const list = (items, cls = '') => `<ul class="suelo-list ${cls}">${items.map(i => `<li>${i}</li>`).join('')}</ul>`;

  function renderSub(sub) {
    $('sueloSubInfo').hidden = false;
    $('sueloSubInfo').innerHTML = `<h3>${esc(sub.nombre)}</h3>
      <div class="suelo-facts">
        <div><span>Provincias</span><strong>${esc(sub.provincias)}</strong></div>
        <div><span>Altitud</span><strong>${esc(sub.altitud)}</strong></div>
      </div>
      <p><b>Clima:</b> ${esc(sub.clima)}</p>
      <p><b>Suelo:</b> ${esc(sub.suelo)}</p>
      <p><b>Peligros típicos de la subregión:</b></p>${list(sub.peligros.map(esc))}
      <p class="suelo-small">Referencia INTA: <a href="${esc(sub.inta.u)}" target="_blank" rel="noopener">${esc(sub.inta.t)}</a></p>`;
  }

  function renderResult(sub, crop) {
    const [lv, note] = crop.aptitud[sub.id];
    const L = LEVELS[lv];
    const win = windowFor(crop, sub.id);
    const recommended = lv !== 'no';
    const alternatives = db.cultivos.filter(c => c.aptitud[sub.id][0] === 'alta' && c.id !== crop.id).map(c => esc(c.nombre));
    const timing = recommended ? `
      <section class="suelo-block"><h4>📅 ¿Cuándo es favorable plantar?</h4>
        <p><b>Ventana:</b> ${esc(win.texto)}</p>
        <p><b>Estación:</b> ${esc(seasonsText(win.meses))} · ${esc(crop.estacion)}</p>
        ${monthStrip(win.meses)}<p>${timingMessage(win.meses)}</p>
      </section>` : `
      <section class="suelo-block"><h4>📅 ¿Cuándo es favorable plantar?</h4>
        <p>No hay una ventana recomendada en esta subregión porque el cultivo no suele prosperar. ${alternatives.length ? `Cultivos con aptitud alta aquí: <b>${alternatives.join(', ')}</b>.` : ''}</p>
      </section>`;
    $('sueloResult').innerHTML = `
      <article class="suelo-card nivel-${L.cls}">
        <div class="suelo-head"><span class="suelo-pill ${L.cls}">${L.label}</span>
          <div><h3>${esc(crop.nombre)} en ${esc(sub.nombre)}</h3><small>${esc(crop.tipo)}</small></div></div>
        <p class="suelo-verdict">${esc(note)}</p>
        ${(lv === 'baja' || lv === 'no') ? '<p class="suelo-nofit">⛔ No se recomienda plantar este cultivo en esta subregión: no es apto.</p>' : ''}
        ${timing}
        <section class="suelo-block"><h4>🌡️ Requerimientos del cultivo</h4>
          <p><b>Clima:</b> ${esc(crop.clima)}</p><p><b>Agua:</b> ${esc(crop.agua)}</p></section>
        <section class="suelo-block"><h4>🪱 Suelo de la subregión</h4><p>${esc(sub.suelo)}</p>
          <p class="suelo-small">Para decidir en un lote concreto conviene un análisis de suelo (textura, pH, materia orgánica, fósforo, conductividad eléctrica) y consultar los mapas de <a href="https://visor.geointa.inta.gob.ar/" target="_blank" rel="noopener">GeoINTA</a>.</p></section>
        <section class="suelo-block suelo-pests"><h4>🐛 Plagas y enfermedades a vigilar</h4>
          ${list(crop.plagas.map(p => `<b>${esc(p.n)}</b><br><span>${esc(p.d)}</span>`))}</section>
        <section class="suelo-block suelo-danger"><h4>⚠️ Peligros y riesgos</h4>
          <p><b>Del cultivo:</b></p>${list(crop.peligros.map(esc))}
          <p><b>De la subregión:</b></p>${list(sub.peligros.map(esc))}</section>
        <section class="suelo-block"><h4>✅ Recomendaciones</h4>${list(crop.recomendaciones.map(esc))}</section>
      </article>`;
  }

  // Botón de AgroBot reutilizable (cultivo desconocido o región sin base de datos).
  function botBlock(question) {
    return `<button type="button" class="map-action-button" id="sueloAskBot">Preguntar a AgroBot</button><div id="sueloBotAnswer" class="suelo-bot"></div>`;
  }
  function wireBot(question) {
    $('sueloAskBot').addEventListener('click', async () => {
      const out = $('sueloBotAnswer'); out.textContent = 'AgroBot está pensando…';
      try {
        const r = await fetch('/api/chat', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ message: question, history: [] }) });
        const d = await r.json().catch(() => ({}));
        out.textContent = r.ok ? (d.answer || 'Sin respuesta.') : (d.detail || d.message || 'AgroBot no está disponible.');
      } catch (e) { out.textContent = 'No se pudo consultar a AgroBot.'; }
    });
  }

  function renderUnknown(text, sub) {
    const names = db.cultivos.map(c => esc(c.nombre)).join(', ');
    $('sueloResult').innerHTML = `<article class="suelo-card"><p class="suelo-verdict">No tengo «${esc(text)}» en la base de cultivos de ${esc(db.region.nombre)}.</p>
      <p>Cultivos disponibles: <b>${names}</b>.</p>
      <p class="suelo-small">Podés preguntarle a AgroBot (requiere la API de Groq configurada) o consultar la Estación Experimental del INTA de la zona.</p>
      ${botBlock()}</article>`;
    wireBot(`¿Es apto el cultivo "${text}" en la subregión "${sub.nombre}" de ${db.region.nombre} (Argentina)? Indicá época de siembra, plagas y peligros según INTA.`);
  }

  function evaluate() {
    const regionId = $('sueloRegion').value;
    const text = $('sueloCrop').value.trim();
    if (!regionId || !dbs[regionId]) { $('sueloResult').innerHTML = '<p class="error-message">Hacé clic en un punto de Argentina en el mapa: la región y la subregión se detectan automáticamente.</p>'; return; }
    db = dbs[regionId];
    const sub = db.subregiones.find(s => s.id === $('sueloSub').value);
    if (!sub) { $('sueloResult').innerHTML = '<p class="error-message">No se pudo determinar la subregión de este punto. Probá con otro punto del mapa.</p>'; return; }
    if (!text) { $('sueloResult').innerHTML = '<p class="error-message">Elegí un cultivo de la lista.</p>'; return; }
    const crop = findCrop(text);
    crop ? renderResult(sub, crop) : renderUnknown(text, sub);
  }

  // Cambia la base activa: lista de cultivos, etiqueta y fuentes según la región detectada.
  function setRegionDb(regionId) {
    db = dbs[regionId] || null;
    const sel = $('sueloCrop'), tag = $('sueloTag'), src = $('sueloSources'), note = $('sueloNote');
    if (!db) {
      sel.innerHTML = '<option value="">Primero elegí un punto en el mapa</option>'; sel.disabled = true;
      tag.textContent = 'INTA · Argentina'; src.hidden = true; note.hidden = true;
      return;
    }
    // Lista desplegable (no editable): se conserva el cultivo elegido si también existe en la nueva región.
    const prev = sel.value;
    sel.innerHTML = '<option value="">Elegí un cultivo</option>' + db.cultivos.map(c => `<option value="${esc(c.nombre)}">${esc(c.nombre)}</option>`).join('');
    sel.disabled = false;
    if (db.cultivos.some(c => c.nombre === prev)) sel.value = prev;
    tag.textContent = 'INTA · ' + db.region.nombre.split(' – ')[0];
    note.hidden = false; note.innerHTML = `<b>Importante:</b> ${esc(db.aviso)}`;
    src.hidden = false;
    src.innerHTML = `Fuentes de referencia: ${db.fuentes.map(f => `<a href="${esc(f.u)}" target="_blank" rel="noopener">${esc(f.t)}</a>`).join(' · ')}`;
  }

  // Los selectores de región y subregión están SIEMPRE bloqueados (disabled = true):
  // se completan solos a partir del punto elegido en el mapa.
  function fillSubs(regionId) {
    const s = $('sueloSub'); $('sueloSubInfo').hidden = true;
    s.disabled = true; $('sueloRegion').disabled = true;
    if (!regionId || !dbs[regionId]) { s.innerHTML = '<option value="">Se detecta desde el mapa</option>'; return; }
    s.innerHTML = '<option value="">Seleccionar subregión</option>' + dbs[regionId].subregiones.map(x => `<option value="${esc(x.id)}">${esc(x.nombre)}</option>`).join('');
  }

  // Aplica lo detectado en el mapa: banner + selectores (bloqueados) + evaluación automática si ya hay un cultivo escrito.
  function applyDetection(d) {
    if (!d || !Object.keys(dbs).length) return;
    const banner = $('sueloLocBanner');
    const place = [d.name, d.province, d.country].filter(Boolean).join(', ') || 'Punto seleccionado';
    const coords = `${d.lat.toFixed(4)}, ${d.lon.toFixed(4)}`;
    const elev = d.elevation != null ? ` · ${d.elevation.toLocaleString('es-AR')} m s. n. m.` : '';
    if (d.argentina === true && d.region && dbs[d.region.id]) {
      setRegionDb(d.region.id);
      banner.innerHTML = `📍 <b>${esc(place)}</b> (${coords})${elev}<br>Región <b>${esc(d.region.nombre)}</b> · Subregión <b>${esc(d.sub.nombre)}</b> <small>(estimada por provincia, posición y altitud; confirmá con el INTA local)</small>`;
      $('sueloRegion').value = d.region.id; fillSubs(d.region.id);
      $('sueloSub').value = d.sub.id;
      const sub = db.subregiones.find(x => x.id === d.sub.id);
      if (sub) renderSub(sub);
      if ($('sueloCrop').value.trim()) evaluate();
      else $('sueloResult').innerHTML = '<p class="muted">Ubicación detectada. Elegí el cultivo que querés plantar y presioná «Evaluar aptitud».</p>';
    } else {
      banner.innerHTML = d.argentina === false
        ? `📍 <b>${esc(place)}</b> (${coords})<br>Este punto está <b>fuera de Argentina</b>: la base de aptitud del INTA no aplica.`
        : `📍 <b>${esc(place)}</b> (${coords})<br>No se pudo determinar la región de este punto. Elegí otro punto dentro de Argentina en el mapa.`;
      setRegionDb(''); $('sueloRegion').value = ''; fillSubs('');
      $('sueloResult').innerHTML = '<p class="muted">Elegí un punto de Argentina en el mapa para que se detecten la región y la subregión.</p>';
    }
    banner.hidden = false;
  }

  function build() {
    const sec = document.createElement('section');
    sec.className = 'panel feature-panel suelo-panel';
    sec.id = 'sueloSection';
    const regions = Object.values(window.AgroRegiones?.REGIONS || {});
    sec.innerHTML = `
      <div class="panel-heading"><div><h2>Análisis de suelo y aptitud agrícola</h2><p>Elegí un punto en el mapa: la región y la subregión se detectan solas. Elegí el cultivo de la lista y consultá aptitud, época de siembra, plagas y peligros.</p></div><span class="tag" id="sueloTag">INTA · Argentina</span></div>
      <div id="sueloLocBanner" class="suelo-banner" hidden></div>
      <div class="suelo-controls">
        <div><label for="sueloRegion">Región</label><select id="sueloRegion" class="feature-select" disabled><option value="">Se detecta desde el mapa</option>${regions.map(r => `<option value="${esc(r.id)}">${esc(r.nombre)}</option>`).join('')}</select></div>
        <div><label for="sueloSub">Subregión</label><select id="sueloSub" class="feature-select" disabled><option value="">Se detecta desde el mapa</option></select></div>
        <div><label for="sueloCrop">Cultivo que querés plantar</label><select id="sueloCrop" class="feature-select" disabled><option value="">Primero elegí un punto en el mapa</option></select></div>
        <button type="button" class="primary-button" id="sueloEvalBtn">Evaluar aptitud</button>
      </div>
      <div id="sueloSubInfo" class="suelo-subinfo" hidden></div>
      <div id="sueloResult" class="suelo-result" aria-live="polite"><p class="muted">Hacé clic en el mapa, elegí un cultivo de la lista y presioná «Evaluar aptitud».</p></div>
      <p class="data-source-note" id="sueloNote" hidden></p>
      <p class="data-source-note" id="sueloSources" hidden></p>`;
    const anchor = $('misParcelasSection');
    anchor ? anchor.before(sec) : (document.querySelector('main') || document.body).appendChild(sec);

    $('sueloEvalBtn').addEventListener('click', evaluate);
    // Al elegir otro cultivo de la lista se re-evalúa automáticamente.
    $('sueloCrop').addEventListener('change', () => { if ($('sueloRegion').value && $('sueloCrop').value.trim()) evaluate(); });
  }

  let starting = false;
  async function init() {
    if (starting || Object.keys(dbs).length) return;
    starting = true;
    try {
      await Promise.all(Object.entries(DATA_URLS).map(async ([id, url]) => {
        const r = await fetch(url);
        if (!r.ok) throw new Error(url + ' → HTTP ' + r.status);
        dbs[id] = await r.json();
      }));
      build();
      // Si el usuario ya había elegido un punto antes de que cargara este módulo.
      if (window.AgroRegiones?.last) applyDetection(window.AgroRegiones.last);
    } catch (e) { console.error('Análisis de suelo: no se pudo cargar los datos', e); starting = false; }
  }
  document.addEventListener('agro:region-detected', e => applyDetection(e.detail));
  document.addEventListener('DOMContentLoaded', init);
  if (document.readyState !== 'loading') init();
})();
