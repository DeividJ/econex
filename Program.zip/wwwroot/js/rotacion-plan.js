/* Crop sequence guidance: preliminary and educational; no agronomic prescriptions. */
(()=>{
 'use strict';
 const $=id=>document.getElementById(id);
 const previous=$('rotationPreviousCrop'),goal=$('rotationGoal'),output=$('rotationPlanResult');
 if(!previous||!goal||!output)return;
 const tr=(en,es)=>document.documentElement.lang==='es'?es:en;
 const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
 const crops={
  trigo:{en:'Wheat',es:'Trigo',family:'grass',legume:false,residue:'medium',market:'grain'},
  soja:{en:'Soybean',es:'Soja',family:'legume',legume:true,residue:'low',market:'oilseed'},
  maiz:{en:'Maize',es:'Maíz',family:'grass',legume:false,residue:'high',market:'grain'},
  sorgo:{en:'Sorghum',es:'Sorgo',family:'grass',legume:false,residue:'high',market:'grain'},
  algodon:{en:'Cotton',es:'Algodón',family:'malvaceae',legume:false,residue:'medium',market:'fiber'},
  poroto:{en:'Common bean',es:'Poroto',family:'legume',legume:true,residue:'low',market:'pulse'},
  alfalfa:{en:'Alfalfa',es:'Alfalfa',family:'legume',legume:true,residue:'high',market:'forage'},
  arroz:{en:'Rice',es:'Arroz',family:'grass',legume:false,residue:'medium',market:'grain'},
  cebada:{en:'Barley',es:'Cebada',family:'grass',legume:false,residue:'medium',market:'grain'},
  mani:{en:'Peanut',es:'Maní',family:'legume',legume:true,residue:'low',market:'oilseed'},
  cana:{en:'Sugarcane',es:'Caña de azúcar',family:'grass',legume:false,residue:'high',market:'industrial'},
  vid:{en:'Grapevine',es:'Vid',family:'vine',legume:false,residue:'low',market:'perennial',perennial:true},
  cebolla:{en:'Onion',es:'Cebolla',family:'allium',legume:false,residue:'low',market:'vegetable'},
  papa:{en:'Potato',es:'Papa',family:'solanaceae',legume:false,residue:'low',market:'vegetable'},
  durazno:{en:'Peach',es:'Duraznero',family:'rosaceae',legume:false,residue:'medium',market:'orchard',perennial:true},
  ciruela:{en:'Plum',es:'Ciruelo',family:'rosaceae',legume:false,residue:'medium',market:'orchard',perennial:true},
  tomate:{en:'Tomato',es:'Tomate',family:'solanaceae',legume:false,residue:'low',market:'vegetable'},
  manzana:{en:'Apple',es:'Manzano',family:'rosaceae',legume:false,residue:'medium',market:'orchard',perennial:true},
  pera:{en:'Pear',es:'Peral',family:'rosaceae',legume:false,residue:'medium',market:'orchard',perennial:true},
  girasol:{en:'Sunflower',es:'Girasol',family:'asteraceae',legume:false,residue:'medium',market:'oilseed'}
 };
 const regional={
  NOA:['trigo','soja','maiz','sorgo','algodon','poroto','cana','vid','alfalfa','girasol'],
  NEA:['soja','maiz','sorgo','algodon','arroz','poroto','cana','trigo','girasol'],
  Pampeana:['trigo','soja','maiz','sorgo','cebada','alfalfa','mani','papa','girasol'],
  Cuyo:['vid','cebolla','alfalfa','trigo','cebada','durazno','ciruela','tomate'],
  Patagonia:['cebada','trigo','alfalfa','papa','manzana','pera','vid','cebolla']
 };
 const preferences={fertility:['alfalfa','poroto','soja','mani','sorgo','maiz','trigo','cebada'],income:['girasol','poroto','algodon','cebolla','maiz','soja','trigo','cebada','sorgo','papa']};
 const names=k=>crops[k]?.[document.documentElement.lang==='es'?'es':'en']||k;
 const para=(container,text)=>{const p=document.createElement('p');p.textContent=text;container.append(p);};
 const heading=(container,text)=>{const h=document.createElement('h3');h.textContent=text;container.append(h);};
 function fillPrevious(){
  const current=previous.value;
  previous.replaceChildren(new Option(tr('Choose a previous crop','Elegí el cultivo anterior'),''));
  Object.keys(crops).sort((a,b)=>names(a).localeCompare(names(b),document.documentElement.lang)).forEach(k=>previous.add(new Option(names(k),k)));
  previous.value=current;
 }
 function number(id,max){
  const raw=$(id)?.value?.trim();if(!raw)return null;
  const n=Number(raw.replace(',','.'));return Number.isFinite(n)&&n>=0&&n<=max?n:NaN;
 }
 function conditions(candidate){
  const ph=number('rotationPh',14),psi=number('rotationSodium',100),ece=number('rotationConductivity',100);
  const ranges={trigo:[6,7.5,6],soja:[6,7,5],maiz:[6,7,1.7],sorgo:[6,7.5,6.8],algodon:[6,7.5,7.7],cebada:[6,7.5,8],alfalfa:[6.5,7,2],arroz:[6,7,3],mani:[6,7,3.2],poroto:[6,7,1],cana:[6,7,1.7],vid:[6,7,1.5],cebolla:[6,7,1.2],papa:[5,6,1.7],durazno:[6,7,1.7],ciruela:[6,7,1.5],tomate:[6,7,2.5]};
  const r=ranges[candidate];const all=[ph,psi,ece].every(x=>x!==null&&Number.isFinite(x));
  if(!all)return {penalty:0,note:tr('No complete, valid soil-test values are available. The crop cannot be cleared for planting based on soil chemistry. Enter pH, exchangeable sodium (ESP/PSI) and saturated-paste electrical conductivity (ECe) in the fields above.','No están completos los tres valores válidos de laboratorio. No se puede confirmar la aptitud de siembra por la química del suelo. Completá pH, sodio intercambiable (PSI) y conductividad de extracto saturado (ECe) en los campos superiores.')};
  let penalty=0;const issues=[];
  if(r){if(ph<r[0]||ph>r[1]){penalty+=25;issues.push(tr(`pH ${ph} lies outside the indicative range ${r[0]}–${r[1]}`,`pH ${ph} fuera del rango orientativo ${r[0]}–${r[1]}`));}if(ece>r[2]){penalty+=35;issues.push(tr(`ECe ${ece} dS/m exceeds the crop screening threshold ${r[2]} dS/m`,`ECe ${ece} dS/m supera el umbral orientativo ${r[2]} dS/m`));}}
  if(psi>15){penalty+=25;issues.push(tr(`ESP ${psi}% exceeds the general sodicity warning threshold (15%)`,`PSI ${psi} % supera el umbral general de alerta por sodicidad (15 %)`));}
  let note=issues.length?tr('Soil-related cautions: ','Advertencias por suelo: ')+issues.join('; ')+'.':tr('The supplied measurements do not exceed the screening thresholds available for this crop. This does not establish overall suitability.','Los valores informados no superan los umbrales disponibles para este cultivo. Eso no confirma por sí solo su aptitud integral.');
  if(!r)note+=' '+tr('No complete crop-specific pH/ECe reference is available in this module.','No hay una referencia completa de pH/ECe para este cultivo en este módulo.');
  note+=' '+tr('Do not add sodium or salts to reach a threshold; those are risk limits, not required inputs.','No agregues sodio ni sales para llegar a un umbral: son límites de riesgo, no nutrientes faltantes.');
  return {penalty,note};
 }
 function suggest(){
  const region=Object.keys(regional).find(r=>norm(r)===norm($('rotationRegion')?.textContent));
  if(!region){output.textContent=tr('Select a plot in a recognized Argentine region first.','Primero seleccioná una parcela de una región argentina reconocida.');return;}
  const old=previous.value,objective=goal.value;
  if(!crops[old]){output.textContent=tr('Choose the previous crop from the list.','Elegí el cultivo anterior de la lista.');return;}
  const eligible=regional[region].filter(k=>k!==old&&!crops[k].perennial&&crops[k].family!==crops[old].family);
  if(crops[old].perennial){output.textContent=tr('The previous crop is perennial. A replacement is not a conventional annual rotation: first assess removal costs, soil history and establishment with an agronomist.','El cultivo anterior es perenne. Reemplazarlo no es una rotación anual convencional: evaluá primero costos de erradicación, antecedentes del suelo e implantación con un ingeniero agrónomo.');return;}
  if(!eligible.length){output.textContent=tr('No suitable candidate is available from the regional screening catalog.','No hay una alternativa disponible en el catálogo regional preliminar.');return;}
  const sorted=eligible.map(k=>{const info=conditions(k);let rank=(preferences[objective]||[]).indexOf(k);if(rank<0)rank=25;
   const fit=objective==='fertility'?(crops[k].legume? -16:0)+(crops[k].residue==='high'?-4:0):crops[k].market!==crops[old].market?-10:0;
   return {key:k,score:rank*3+info.penalty+fit,soil:info};}).sort((a,b)=>a.score-b.score||names(a.key).localeCompare(names(b.key)));
  const rec=sorted[0],next=crops[rec.key],oldCrop=crops[old];
  output.replaceChildren();heading(output,tr(`Suggested next crop to evaluate: ${names(rec.key)}`,`Siguiente cultivo sugerido para evaluar: ${names(rec.key)}`));
  para(output,tr(`Selected plot region: ${region}. Previous crop: ${names(old)}. Goal: ${objective==='fertility'?'improve soil fertility and replenish nutrients':'diversify revenue and reduce risk'}. This is a shortlist recommendation, not a confirmed planting decision.`,`Región de la parcela: ${region}. Cultivo anterior: ${names(old)}. Objetivo: ${objective==='fertility'?'mejorar la fertilidad y reponer nutrientes':'diversificar ingresos y reducir riesgos'}. Es una alternativa para estudiar, no una autorización definitiva para sembrar.`));
  heading(output,tr('Why this alternative?', '¿Por qué se sugiere?'));
  if(objective==='fertility'){
   para(output,next.legume?tr(`${names(rec.key)} is a legume and may fix atmospheric nitrogen through effective symbiosis when suitable inoculation, nutrition and conditions are provided. This does not replenish phosphorus, potassium or other minerals; harvesting removes nutrients and soil tests are needed to quantify replacement.`,`Se prioriza ${names(rec.key)} porque es una leguminosa que puede fijar nitrógeno atmosférico mediante simbiosis eficaz, si tiene inoculación y condiciones apropiadas. Eso NO repone fósforo, potasio ni otros minerales: la cosecha extrae nutrientes y se requiere análisis para calcular reposición.`):tr(`${names(rec.key)} provides a different crop type; crop residues and rotations may support soil management, but it cannot be assumed to replenish nutrients. Soil nutrient budgets and fertilization plans are still necessary.`,`Se considera ${names(rec.key)} por aportar una secuencia diferente. Los rastrojos y la rotación pueden contribuir al manejo del suelo, pero no se debe asumir que repone minerales. Sigue siendo necesario un balance de nutrientes y un plan de fertilización.`));
  }else{
   para(output,tr(`${names(rec.key)} belongs to a ${next.market} production segment, compared with the previous crop (${oldCrop.market}). This may diversify prices and sales channels, but revenue depends on local demand, investment, machinery, labor, storage and market access. Compare expected net margins rather than assuming higher profit.`,`Se considera ${names(rec.key)} como alternativa comercial (${next.market}) frente al cultivo anterior (${oldCrop.market}). Puede diversificar mercados y precios, pero los ingresos dependen de demanda local, inversión, maquinaria, mano de obra, almacenamiento y compradores. Compará márgenes netos esperados; no se garantiza mayor ganancia.`));
  }
  para(output,tr(`The botanical family changes (${oldCrop.family} → ${next.family}). This can diversify crop sequences, but it does not guarantee control of pests, diseases or weeds.`,`Se cambia la familia botánica (${oldCrop.family} → ${next.family}). Esto diversifica la secuencia de cultivos, pero no garantiza controlar plagas, enfermedades ni malezas.`));
  heading(output,tr('Soil test comparison','Comparación con el análisis de suelo'));
  para(output,rec.soil.note);
  heading(output,tr('Before deciding to sow','Qué verificar antes de decidir la siembra'));
  const checks=objective==='fertility'?
   [tr('Order a complete fertility analysis (at least organic matter, N availability, phosphorus, potassium and relevant micronutrients), including sample depth and lab method.','Solicitá un análisis completo de fertilidad (materia orgánica, disponibilidad de nitrógeno, fósforo, potasio y micronutrientes pertinentes), con profundidad y método de muestreo.'),tr('Estimate nutrient removal by the previous harvest and potential removal by the next crop; set rates only with an agronomist.','Calculá la extracción de nutrientes de la cosecha anterior y la esperada para la próxima; definí dosis únicamente con un ingeniero agrónomo.'),tr('Review residue cover, erosion, compaction, inoculation needs and actual soil moisture.','Revisá cobertura de rastrojos, erosión, compactación, inoculación cuando corresponda y humedad real del perfil.')]:
   [tr('Estimate establishment costs, projected yield, selling price, freight and net margin under optimistic and adverse scenarios.','Estimá costos de implantación, rendimiento posible, precio de venta, flete y margen neto bajo escenarios favorables y desfavorables.'),tr('Verify local buyers, marketing contracts, harvesting machinery, storage and labor availability.','Verificá compradores locales, contratos comerciales, maquinaria de cosecha, almacenamiento y disponibilidad de mano de obra.'),tr('Consider weather hazards, irrigation needs, insurance and market concentration before switching crops.','Evaluá amenazas climáticas, necesidades de riego, seguros y concentración de mercado antes de cambiar de cultivo.')];
  checks.push(tr('Confirm local planting window, soil water reserves, drainage, previous herbicide residual effects and relevant pests with an agronomist.','Confirmá calendario regional de siembra, reservas de agua, drenaje, herbicidas residuales y plagas relevantes con un ingeniero agrónomo.'));
  const ul=document.createElement('ul');checks.forEach(t=>{const li=document.createElement('li');li.textContent=t;ul.append(li);});output.append(ul);
  const other=sorted.slice(1,3).map(x=>names(x.key));if(other.length)para(output,tr(`Other regional alternatives to compare: ${other.join(', ')}.`,`Otras alternativas regionales para comparar: ${other.join(', ')}.`));
  const disclaimer=document.createElement('small');disclaimer.textContent=tr('Indicative regional screening only. No climate forecast, planting calendar, full nutrient analysis or profitability model is included in this rotation ranking.','Evaluación regional orientativa. Esta clasificación no incorpora un pronóstico climático, calendario de siembra específico, análisis nutricional completo ni modelo de rentabilidad.');output.append(disclaimer);
 }
 fillPrevious();
 $('rotationSuggestBtn')?.addEventListener('click',suggest);
 previous.addEventListener('change',()=>{if(previous.value)suggest();});goal.addEventListener('change',()=>{if(previous.value)suggest();});
 document.addEventListener('rotation:parcel-changed',()=>{output.textContent=tr('Choose a previous crop and one of the two goals to evaluate this plot.','Elegí un cultivo anterior y uno de los dos objetivos para evaluar la parcela.');});
 document.addEventListener('agro:language-changed',()=>{fillPrevious();if(previous.value)suggest();});
})();
