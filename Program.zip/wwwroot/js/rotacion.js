(() => {
  'use strict';
  if (typeof L === 'undefined') return;
  const $ = id => document.getElementById(id);
  const ARG_BOUNDS = L.latLngBounds([-55.5, -73.8], [-21.5, -53.5]);
  const apiGeoref = 'https://apis.datos.gob.ar/georef/api';
  const map = L.map('rotationMap', { maxBounds: ARG_BOUNDS, maxBoundsViscosity: 1, minZoom: 4, doubleClickZoom: false }).setView([-34.3, -64.2], 5);
  const street = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, attribution: '&copy; OpenStreetMap contributors'
  });
  const satellite = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 19, attribution: 'Imágenes &copy; Esri'
  });
  const streetLabels = L.tileLayer('https://{s}.basemaps.cartocdn.com/light_only_labels/{z}/{x}/{y}{r}.png', {
    maxZoom: 19, pane: 'overlayPane', attribution: '&copy; CARTO, OpenStreetMap'
  });
  street.addTo(map);
  // Límite visual orientativo de Argentina; no sustituye el catastro provincial.
  fetch("/data/argentina-limite-referencial.geojson").then(r=>r.ok?r.json():null).then(data=>{
    if(data)L.geoJSON(data,{style:{color:"#c78b59",weight:2,opacity:.8,fill:false,dashArray:"5 4"},interactive:false}).addTo(map);
  }).catch(()=>{});
  let mode = 'draw', vertices = [], polygon = null, guide = null, marks = [], previewMap = null;
  let selected = null, locationRequest = 0, saved = [], searchTimeout, selectedPointMarker = null, selectedSavedId = null, lineColor = '#C78B59';
  const regionLookup = {
    'Jujuy':'NOA','Salta':'NOA','Tucumán':'NOA','Catamarca':'NOA','Santiago del Estero':'NOA','La Rioja':'NOA',
    'Formosa':'NEA','Chaco':'NEA','Corrientes':'NEA','Misiones':'NEA',
    'Córdoba':'Pampeana','Santa Fe':'Pampeana','Entre Ríos':'Pampeana','Buenos Aires':'Pampeana','Ciudad Autónoma de Buenos Aires':'Pampeana','La Pampa':'Pampeana',
    'San Juan':'Cuyo','Mendoza':'Cuyo','San Luis':'Cuyo',
    'Neuquén':'Patagonia','Río Negro':'Patagonia','Chubut':'Patagonia','Santa Cruz':'Patagonia','Tierra del Fuego, Antártida e Islas del Atlántico Sur':'Patagonia'
  };
  const clean = s => String(s || '').trim();
  const within = p => ARG_BOUNDS.contains(p);
  const status = (message, error=false) => { $('rotationMapStatus').textContent=message; $('rotationSaveMessage').style.color=error?'#b64b35':''; };
  const display = (id,value) => { $(id).textContent = value===undefined || value===null || value==='' ? '—' : String(value); };
  const setButtons = () => {
    $('rotationUndoBtn').disabled = mode!=='draw'||!vertices.length;
    $('rotationFinishBtn').disabled = mode!=='draw'||vertices.length<3;
    $('rotationSaveBtn').disabled = selectedSavedId !== null ? false : (mode!=='closed'||!selected?.province);
    $('rotationDrawBtn').classList.toggle('is-primary',mode==='draw');
    $('rotationMap').classList.toggle('rotation-drawing',mode==='draw');
    $('rotationCount').textContent=`${vertices.length} ${vertices.length===1?'vértice':'vértices'}`;
  };
  const areaHa = arr => {
    const R=6378137, rad=Math.PI/180;
    let sum=0;
    arr.forEach((a,i)=> { const b=arr[(i+1)%arr.length]; sum+=(b.lng-a.lng)*rad*(2+Math.sin(a.lat*rad)+Math.sin(b.lat*rad)); });
    return Math.abs(sum)*R*R/2/10000;
  };
  const formatHa = val => new Intl.NumberFormat('es-AR',{maximumFractionDigits:2}).format(val)+' ha';
  const crossed = points => {
    const cross=(a,b,c)=>(b.lng-a.lng)*(c.lat-a.lat)-(b.lat-a.lat)*(c.lng-a.lng);
    for(let i=0;i<points.length;i++)for(let j=i+1;j<points.length;j++){
      if(j===i+1||(i===0&&j===points.length-1))continue;
      const a=points[i],b=points[(i+1)%points.length],c=points[j],d=points[(j+1)%points.length];
      if(cross(a,b,c)*cross(a,b,d)<0&&cross(c,d,a)*cross(c,d,b)<0)return true;
    }
    return false;
  };
  function soilValues(){
    const ids=[['rotationPh','ph',14],['rotationSodium','sodiumPercent',100],['rotationConductivity','electricalConductivity',100]];
    const values={};
    for(const [id,key,max] of ids){
      const input=$(id), raw=input.value.trim();
      if(!raw){values[key]=null;continue;}
      const n=Number(raw.replace(',','.'));
      if(!Number.isFinite(n)||n<0||n>max){input.focus();throw new Error(`Revisá ${input.closest('label')?.textContent.trim()||id}: ingresá un valor entre 0 y ${max}.`);}
      values[key]=n;
    }
    return values;
  }
  function clearSoilFields(){['rotationPh','rotationSodium','rotationConductivity'].forEach(id=>$(id).value='');}
  function fillSoil(item){
    $('rotationPh').value=item.ph??'';
    $('rotationSodium').value=item.sodiumPercent??'';
    $('rotationConductivity').value=item.electricalConductivity??'';
  }
  function changeColor(hex){
    if(!/^#[0-9a-f]{6}$/i.test(hex))return;
    lineColor=hex.toUpperCase();$('rotationColor').value=lineColor;
    document.querySelectorAll('#rotationColorOptions [data-color]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.color.toUpperCase()===lineColor)));
    refreshDrawing();if(mode==='closed')showPreview();
  }
  document.querySelectorAll('#rotationColorOptions [data-color]').forEach(b=>b.addEventListener('click',()=>changeColor(b.dataset.color)));
  $('rotationColor').addEventListener('input',e=>changeColor(e.target.value));
  function refreshDrawing(){
    if(guide){map.removeLayer(guide);guide=null;}
    marks.forEach(m=>map.removeLayer(m));marks=[];
    if(polygon){map.removeLayer(polygon);polygon=null;}
    if(vertices.length){
      guide=L.polyline(vertices,{color:lineColor,weight:3,dashArray:'7 7'}).addTo(map);
      vertices.forEach((p,i)=>{
        const marker=L.marker(p,{icon:L.divIcon({className:'',html:`<div class="rotation-vertex-marker ${i===0?'first':''}"></div>`,iconSize:i===0?[17,17]:[12,12],iconAnchor:i===0?[8,8]:[6,6]})}).addTo(map);
        if(i===0){marker.on('click',e=>{L.DomEvent.stopPropagation(e);if(mode==='draw'&&vertices.length>=3)finish();});marker.bindTooltip('Cerrar polígono aquí');}
        marks.push(marker);
      });
    }
    if(mode==='closed'&&vertices.length>=3){polygon=L.polygon(vertices,{color:lineColor,weight:3,fillColor:lineColor,fillOpacity:.16}).addTo(map);}
    const ha=vertices.length>=3?areaHa(vertices):0;
    display('rotationSurface',vertices.length>=3?`Superficie estimada: ${formatHa(ha)}`:'Superficie: —');
    display('rotationArea',mode==='closed'?formatHa(ha):null);
    setButtons();
  }
  function clear(){
    if(selectedPointMarker){map.removeLayer(selectedPointMarker);selectedPointMarker=null;}
    mode='draw';vertices=[];selected=null;selectedSavedId=null;locationRequest++; $('rotationName').value=''; $('rotationSavedSelect').value=''; clearSoilFields();
    ['rotationPlace','rotationProvinceInfo','rotationCountryInfo','rotationLat','rotationLon','rotationAltitude','rotationRegion','rotationSubregion','rotationArea'].forEach((id,i)=>display(id,i===0?'Sin seleccionar':null));
    refreshDrawing(); $('rotationSaveMessage').textContent='Terminá de dibujar el contorno para guardar.';
    if(previewMap){previewMap.remove();previewMap=null;}
    $('rotationPreview').replaceChildren(); const h=document.createElement('span'); h.textContent='Dibujá una parcela para ver su imagen satelital.'; $('rotationPreview').appendChild(h);
    status('Modo dibujo activo: colocá el primer vértice.');
    document.dispatchEvent(new Event('rotation:parcel-changed'));
  }
  function addVertex(p){
    if(!within(p)){status('Elegí un punto dentro del área de Argentina.',true);return;}
    if(vertices.length>=300){status('Máximo 300 vértices.',true);return;}
    if(vertices.length>=3&&map.latLngToContainerPoint(p).distanceTo(map.latLngToContainerPoint(vertices[0]))<=14){finish();return;}
    if(vertices.some(v=>v.distanceTo(p)<.5)){status('Ese punto está muy cerca de otro vértice.',true);return;}
    vertices.push(p);refreshDrawing();
    status(vertices.length<3?'Agregá más vértices para formar un terreno.':'Continuá dibujando o presioná «Finalizar contorno».');
    if(vertices.length===1) lookup(p); // Mostrar los datos desde la selección del primer punto.
  }
  function finish(){
    if(vertices.length<3){status('Necesitás al menos tres vértices.',true);return;}
    if(crossed(vertices)){status('Las líneas del polígono se cruzan. Usá «Deshacer punto» y corregí el contorno.',true);return;}
    const ha=areaHa(vertices);
    if(ha<.001||ha>1e8){status('Superficie inválida; ajustá los puntos.',true);return;}
    mode='closed';refreshDrawing();
    document.dispatchEvent(new Event('rotation:parcel-changed'));
    map.fitBounds(L.latLngBounds(vertices).pad(.5),{maxZoom:16});
    showPreview();
    const point=L.latLng(vertices.reduce((a,p)=>a+p.lat,0)/vertices.length,vertices.reduce((a,p)=>a+p.lng,0)/vertices.length);
    status('Contorno cerrado. Consultando provincia, localidad y altitud…');
    lookup(point);
  }
  function showPreview(){
    if(previewMap){previewMap.remove();previewMap=null;}
    $('rotationPreview').replaceChildren();
    previewMap=L.map('rotationPreview',{zoomControl:false,attributionControl:true,dragging:false,scrollWheelZoom:false,doubleClickZoom:false,boxZoom:false,keyboard:false,touchZoom:false});
    L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{x}/{y}/{x}',{attribution:'Esri'});
    L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{x}/{y}',{maxZoom:19,attribution:'Esri'}).addTo(previewMap);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/light_only_labels/{z}/{x}/{y}{r}.png',{maxZoom:19,attribution:'CARTO'}).addTo(previewMap);
    L.polygon(vertices,{color:lineColor,weight:4,fillColor:lineColor,fillOpacity:.12}).addTo(previewMap);
    previewMap.fitBounds(L.latLngBounds(vertices).pad(.4),{maxZoom:17});
    setTimeout(()=>previewMap?.invalidateSize(),100);
  }
  async function lookup(p){
    const request=++locationRequest;
    display('rotationLat',p.lat.toFixed(6));display('rotationLon',p.lng.toFixed(6));
    display('rotationCountryInfo','Argentina');
    // Estas coordenadas describen un punto central representativo de la geometría.
    let info={lat:p.lat,lon:p.lng,province:'',locality:'',country:'Argentina',altitude:null,region:'',subregion:''};
    try{
      const q=`${apiGeoref}/ubicacion?lat=${encodeURIComponent(p.lat)}&lon=${encodeURIComponent(p.lng)}&campos=estandar`;
      const r=await fetch(q);if(!r.ok)throw new Error('GeoRef');
      const d=await r.json();const v=d.ubicacion||{};
      info.province=clean(v.provincia?.nombre);info.locality=clean(v.localidad_censal?.nombre||v.localidad?.nombre||v.municipio?.nombre||v.departamento?.nombre);
      info.subregion=clean(v.departamento?.nombre||v.municipio?.nombre||v.localidad_censal?.nombre);
    }catch{ /* Cuando falla Georef, se consulta OSM con restricción de país. */ }
    if(!info.province){
      try{
        const r=await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(p.lat)}&lon=${encodeURIComponent(p.lng)}&zoom=12&addressdetails=1&accept-language=es`);
        if(r.ok){const d=await r.json();const a=d.address||{};
          if(clean(a.country_code).toLowerCase()==='ar'){
            info.province=clean(a.state||a.province);info.locality=clean(a.city||a.town||a.village||a.municipality||a.county);
            info.subregion=clean(a.county||a.state_district||a.municipality);
          }
        }
      }catch{}
    }
    try{
      const r=await fetch(`https://api.open-meteo.com/v1/elevation?latitude=${encodeURIComponent(p.lat)}&longitude=${encodeURIComponent(p.lng)}`);
      if(r.ok){const d=await r.json();if(Number.isFinite(d.elevation?.[0]))info.altitude=d.elevation[0];}
    }catch{}
    if(request!==locationRequest)return;
    info.region=regionLookup[info.province]||'Sin clasificar';
    selected=info;
    display('rotationPlace',info.locality||'Ubicación seleccionada');
    display('rotationProvinceInfo',info.province||'No disponible');
    display('rotationCountryInfo','Argentina');
    display('rotationAltitude',info.altitude===null?'No disponible':`${Math.round(info.altitude)} m (estimada)`);
    display('rotationRegion',info.region);
    display('rotationSubregion',info.subregion||'No disponible');
    if(!$('rotationName').value && info.locality)$('rotationName').value=`Lote · ${info.locality}`.slice(0,120);
    setButtons();
    document.dispatchEvent(new Event('rotation:parcel-changed'));
    if(mode==='closed'){
      $('rotationSaveMessage').textContent=info.province?'Contorno listo para guardar.':'No se pudo confirmar la provincia. Probá nuevamente con otra ubicación o conexión.';
      status(info.province?'Parcela lista. Revisá el nombre y guardala.':'No se confirmó la provincia; verificá la ubicación.',!info.province);
    }
  }
  async function loadProvinces(){
    try{const r=await fetch(`${apiGeoref}/provincias?campos=id,nombre,centroide&max=100`);if(!r.ok)throw Error();const d=await r.json();
      (d.provincias||[]).sort((a,b)=>a.nombre.localeCompare(b.nombre,'es')).forEach(p=>{
        const o=document.createElement('option');o.value=p.id;o.textContent=p.nombre;o.dataset.lat=p.centroide?.lat||'';o.dataset.lon=p.centroide?.lon||'';$('rotationProvince').append(o);
      });
    }catch{status('No se pudo cargar la lista de provincias. El mapa y la búsqueda siguen disponibles.',true);}
  }
  $('rotationProvince').addEventListener('change',async e=>{
    const v=e.target.value,option=e.target.selectedOptions[0];$('rotationLocality').replaceChildren(new Option('Elegí una localidad',''));
    if(!v){$('rotationLocality').disabled=true;return;}
    if(option?.dataset.lat&&option?.dataset.lon)map.setView([Number(option.dataset.lat),Number(option.dataset.lon)],8);
    try{const r=await fetch(`${apiGeoref}/localidades?provincia=${encodeURIComponent(v)}&campos=nombre,centroide&max=5000&orden=nombre`);if(!r.ok)throw Error();const d=await r.json();
      (d.localidades||[]).forEach(l=>{if(!l.centroide)return;const o=new Option(l.nombre,l.nombre);o.dataset.lat=l.centroide.lat;o.dataset.lon=l.centroide.lon;$('rotationLocality').append(o);});$('rotationLocality').disabled=false;
    }catch{status('No se pudo cargar las localidades de esta provincia.',true);}
  });
  $('rotationLocality').addEventListener('change',e=>{const o=e.target.selectedOptions[0];if(o?.dataset.lat&&o?.dataset.lon)map.setView([Number(o.dataset.lat),Number(o.dataset.lon)],12);});
  async function search(){
    const term=clean($('rotationSearch').value);if(term.length<3){status('Escribí al menos tres caracteres para buscar.',true);return;}
    const box=$('rotationSearchResults');box.textContent='Buscando…';
    try{const q=new URLSearchParams({q:term,format:'jsonv2',limit:'6',countrycodes:'ar',addressdetails:'1', 'accept-language':'es'});
      const r=await fetch(`https://nominatim.openstreetmap.org/search?${q}`);if(!r.ok)throw Error();const list=await r.json();box.replaceChildren();
      if(!list.length){box.textContent='No se encontraron lugares dentro de Argentina.';return;}
      list.forEach(item=>{const b=document.createElement('button');b.type='button';b.textContent=item.display_name;b.addEventListener('click',()=>{
        const p=L.latLng(Number(item.lat),Number(item.lon));if(within(p))map.setView(p,Math.max(map.getZoom(),13));box.replaceChildren();$('rotationSearch').value=item.display_name;
      });box.append(b);});
    }catch{box.textContent='Búsqueda no disponible en este momento. Usá los filtros de provincia o el mapa.';}
  }
  $('rotationSearchBtn').addEventListener('click',search);
  $('rotationSearch').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();search();}});
  $('rotationDrawBtn').addEventListener('click',()=>{if(mode==='closed'||mode==='point')clear();else {mode='draw';setButtons();status('Marcá los vértices sobre el mapa.');}});
  $('rotationUndoBtn').addEventListener('click',()=>{if(mode!=='draw')return;vertices.pop();refreshDrawing();status('Último punto eliminado.');});
  $('rotationFinishBtn').addEventListener('click',finish);
  $('rotationClearBtn').addEventListener('click',clear);
  map.on('click',e=>{if(mode==='draw')addVertex(e.latlng);});
  $('rotationStreets').addEventListener('click',()=>{
    map.removeLayer(satellite);map.removeLayer(streetLabels);if(!map.hasLayer(street))street.addTo(map);
    $('rotationStreets').classList.add('active');$('rotationSatellite').classList.remove('active');
  });
  $('rotationSatellite').addEventListener('click',()=>{
    map.removeLayer(street);if(!map.hasLayer(satellite))satellite.addTo(map);if(!map.hasLayer(streetLabels))streetLabels.addTo(map);
    $('rotationSatellite').classList.add('active');$('rotationStreets').classList.remove('active');
  });
  $('rotationMyLocation').addEventListener('click',()=>{
    if(!navigator.geolocation){status('Este navegador no dispone de geolocalización.',true);return;}
    status('Solicitando ubicación del dispositivo…');
    navigator.geolocation.getCurrentPosition(pos=>{
      const p=L.latLng(pos.coords.latitude,pos.coords.longitude);
      if(!within(p)){status('La ubicación detectada está fuera del área de Argentina.',true);return;}
      map.setView(p,15);status('Ubicación centrada. Marcá los vértices del terreno.');
    },err=>status(err.code===1?'Permití la ubicación desde el navegador. Recordá usar HTTPS o localhost.':'No se pudo determinar la ubicación.',true),{enableHighAccuracy:true,timeout:18000,maximumAge:0});
  });
  async function loadSaved(){
    const picker=$('rotationSavedSelect');
    try{
      const r=await fetch('/api/rotacion/parcelas');
      if(!r.ok)throw Error(`HTTP ${r.status}`);
      saved=await r.json();
      const currentId=selectedSavedId;
      picker.replaceChildren(new Option('＋ Dibujar una parcela nueva',''));
      saved.forEach(item=>picker.add(new Option(`${item.name} · ${item.province}${item.geometry?'':' (sin contorno)'}`,String(item.id))));
      if(currentId!==null && saved.some(x=>x.id===currentId))picker.value=String(currentId);
      document.dispatchEvent(new Event('rotation:parcel-changed'));
    }catch{
      picker.replaceChildren(new Option('No se pudieron cargar parcelas · Revisá SQL Server',''));
      document.dispatchEvent(new Event('rotation:parcel-changed'));
    }
  }
  function showSaved(item){
    clear();selectedSavedId=item.id;$('rotationSavedSelect').value=String(item.id);
    const ring=item.geometry?.coordinates?.[0];
    if(ring?.length>=4){vertices=ring.slice(0,-1).map(([lon,lat])=>L.latLng(lat,lon));mode='closed';}
    else {vertices=[];mode='point';}
    changeColor(item.lineColor||'#C78B59');refreshDrawing();
    if(vertices.length>=3){map.fitBounds(L.latLngBounds(vertices).pad(.35));showPreview();}
    else if(Number.isFinite(Number(item.lat)) && Number.isFinite(Number(item.lon))){const center=[Number(item.lat),Number(item.lon)];map.setView(center,15);selectedPointMarker=L.marker(center).addTo(map).bindPopup('Parcela sin contorno dibujado');}
    fillSoil(item);
    selected={lat:item.lat,lon:item.lon,province:item.province,locality:item.locality||'',country:'Argentina',region:item.region||'',subregion:item.subregion||'',altitude:item.altitude};
    $('rotationName').value=item.name;display('rotationPlace',item.locality||item.name);display('rotationProvinceInfo',item.province);
    display('rotationCountryInfo','Argentina');display('rotationLat',Number(item.lat).toFixed(6));display('rotationLon',Number(item.lon).toFixed(6));
    display('rotationAltitude',item.altitude===null?'No disponible':`${Math.round(Number(item.altitude))} m (estimada)`);
    display('rotationRegion',item.region);display('rotationSubregion',item.subregion);display('rotationArea',formatHa(Number(item.hectares)));
    // Guardar una parcela recuperada actualiza sus análisis y el color, nunca crea duplicados.
    $('rotationSaveMessage').textContent='Parcela recuperada. Podés actualizar el color y los datos de suelo con «Guardar parcela».';
    status(vertices.length?'Mostrando contorno guardado: '+item.name:'Esta parcela se guardó sin contorno: se muestra su punto de ubicación. Podés guardar sus datos de suelo o iniciar una parcela nueva para dibujar un contorno.');
    setButtons();
    document.dispatchEvent(new Event('rotation:parcel-changed'));
  }
  $('rotationSavedSelect').addEventListener('change',e=>{
    const id=Number(e.target.value);
    if(!e.target.value){clear();return;}
    const item=saved.find(x=>x.id===id);
    if(item)showSaved(item);
  });

  $('rotationSaveBtn').addEventListener('click',async()=>{
    const name=clean($('rotationName').value);
    if(!name){$('rotationSaveMessage').textContent='Ingresá un nombre para la parcela.';$('rotationName').focus();return;}
    if(selectedSavedId===null && (mode!=='closed'||!selected?.province)){
      $('rotationSaveMessage').textContent='Cerrá el contorno y esperá a que se confirme la provincia.';return;
    }
    let soil;
    try{soil=soilValues();}catch(e){$('rotationSaveMessage').textContent=e.message;return;}
    const button=$('rotationSaveBtn');button.disabled=true;button.textContent='Guardando…';
    try{
      const isUpdate=selectedSavedId!==null;
      const body=isUpdate? {name, lineColor, ...soil} :
        {name,locality:selected.locality,province:selected.province,region:selected.region,subregion:selected.subregion,
         altitude:selected.altitude,vertices:vertices.map(p=>[p.lat,p.lng]),lineColor,...soil};
      const endpoint=isUpdate?`/api/rotacion/parcelas/${selectedSavedId}`:'/api/rotacion/parcelas';
      const r=await fetch(endpoint,{method:isUpdate?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
      const data=await r.json();if(!r.ok)throw Error(data.message||data.detail||'Error al guardar.');
      if(!isUpdate && data.id)selectedSavedId=data.id;
      $('rotationSaveMessage').textContent=`✓ ${data.message}${data.hectares!==undefined?' Superficie: '+formatHa(Number(data.hectares)):''}`;
      status('Cambios guardados en SQL Server.');await loadSaved();
      document.dispatchEvent(new Event('rotation:parcel-changed'));
      document.dispatchEvent(new CustomEvent('agro:parcels-changed'));
    }catch(e){$('rotationSaveMessage').textContent=`No se pudo guardar: ${e.message}`;}
    finally{button.textContent='Guardar parcela';setButtons();}
  });
  changeColor(lineColor);loadProvinces();loadSaved();setButtons();setTimeout(()=>map.invalidateSize(),150);
})();
