(() => {
    const clock = document.getElementById("clock");
    const dateLabel = document.getElementById("todayLabel");
    const greeting = document.getElementById("greeting");

    // Saludo según la hora de Argentina: 6–11 día, 12–19 tarde, 20–5 noche.
    function greetingFor(hour) {
        if (hour >= 6 && hour < 12) return "Buen día, productor";
        if (hour >= 12 && hour < 20) return "Buenas tardes, productor";
        return "Buenas noches, productor";
    }
    function argentinaHour(now) {
        return parseInt(new Intl.DateTimeFormat("es-AR", {
            hour: "numeric", hourCycle: "h23", timeZone: "America/Argentina/Buenos_Aires"
        }).format(now), 10);
    }

    function updateClock() {
        const now = new Date();
        if (clock) {
            clock.textContent = new Intl.DateTimeFormat("es-AR", {
                hour: "2-digit", minute: "2-digit", second: "2-digit",
                hour12: false, timeZone: "America/Argentina/Buenos_Aires"
            }).format(now);
        }
        if (greeting) {
            const text = greetingFor(argentinaHour(now));
            if (greeting.textContent !== text) greeting.textContent = text;
        }
        if (dateLabel) {
            dateLabel.textContent = new Intl.DateTimeFormat("es-AR", {
                weekday: "long", day: "numeric", month: "long",
                timeZone: "America/Argentina/Buenos_Aires"
            }).format(now);
        }
    }
    updateClock();
    setInterval(updateClock, 1000);

    const root = document.documentElement;
    const themeToggle = document.getElementById("themeToggle");
    const themeLabel = document.getElementById("themeLabel");
    const themeIcon = document.getElementById("themeIcon");

    function applyTheme(theme) {
        root.setAttribute("data-theme", theme);
        if (themeLabel) themeLabel.textContent = document.documentElement.lang === 'es' ? 'Modo oscuro' : 'Dark mode';
        if (themeToggle) { themeToggle.checked = theme === "dark"; themeToggle.setAttribute('aria-checked',String(theme==='dark')); }
        try { localStorage.setItem("agroalerta-theme", theme); } catch { }
    }

    let savedTheme = "light";
    try { savedTheme = localStorage.getItem("agroalerta-theme") || "light"; } catch { }
    applyTheme(savedTheme);

    themeToggle?.addEventListener("change", () => applyTheme(themeToggle.checked ? "dark" : "light"));
    document.addEventListener('agro:language-changed', () => { applyTheme(root.getAttribute('data-theme') || 'light'); updateClock(); });

    const sidebar = document.getElementById("sidebar");
    const overlay = document.getElementById("mobileOverlay");
    const mobileMenu = document.getElementById("mobileMenu");

    function closeMenu() {
        sidebar?.classList.remove("open");
        overlay?.classList.remove("show");
    }
    mobileMenu?.addEventListener("click", () => {
        sidebar?.classList.toggle("open");
        overlay?.classList.toggle("show");
    });
    overlay?.addEventListener("click", closeMenu);
})();
